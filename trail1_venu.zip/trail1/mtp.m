 clc;
% filename1 = 'students-choices';
% filename2 = 'prof_list-keywords.xlsx';

for i = 1: length(Roll_nos_choices)
    if Roll_nos_choices(i) == Roll_nos_CGPA(i)
        
        sprintf('Roll no %.f ,matched in both files',Roll_nos_choices(i));
    else
        Error_Prone = sprintf('Info about Roll no %.f or %.f are missing in either one of the file',Roll_nos_choices(i),Roll_nos_CGPA(i))
        error('Error, exiting');
    end
end

original_proj_list = txt3;
txt_without_headings = txt(2:end,:);
sorted_txt = txt_without_headings(sort_index,:);



% for i = 1: N_students-1
%     
%     for j = 2: total_choices
%         
%         if contains(sorted_txt(i,j),txt3(j-1,2))
%             Assigned_proj_roll_nos = [txt3(j-1,2) sorted_Roll_nos(i)]
%             txt3(j-1,2) = {'Assigned'};
%             j = 2;
%             break
%             
%         end
%         
%     end
%     
% end
% 
% [original_proj_list txt3(:,2)]